package MINIPROJECT;

import java.awt.Color;
import java.awt.FlowLayout;

import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class showBook 
{

	JFrame F1;
	JOptionPane ob;
	
	showBook()
	{
           
		
		
		JPanel P;
		
		JScrollPane jsp;
		JTable t;
		
		F1 = new JFrame("BOOKS LIST");
		
		F1.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		
		P = new JPanel();
		P.setBackground(Color.GREEN);		
		P.setLayout(new FlowLayout(FlowLayout.CENTER));
				
		F1.add(P);	
				

		    
		    java.sql.Statement st=null;   
			ResultSet re = null;
			
			int i=0;
			
			try
			{
			Class.forName("com.mysql.jdbc.Driver");	 
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/raju","root","");
			st = con.createStatement();
			re = st.executeQuery("Select * from books ");
			
			
			String colmn[] ={"Bookid","Bookname","Bookcost","Book_status"};
			String data[][] = new String[50][4];
			
			while(re.next())
			{
				System.out.println(re.getInt("bid"));
				data[i][0] =Integer.toString(re.getInt("bid"));
				data[i][1] =re.getString("bname");
				data[i][2] =Integer.toString(re.getInt("bcost"));
				data[i][3] =re.getString("issued_status");
				
				i++;
				
				
			}

			t=new JTable(data,colmn);
			jsp=new JScrollPane(t); 
			P.add(jsp);
		
		    con.close();

			
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
			}
		    
			
			
		    F1.setSize(600, 300);
			F1.setVisible(true);
		    
		    
	}

	
	
	
	
}
