package MINIPROJECT;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class STUDENT implements ActionListener
{
	
	JFrame F;
	JLabel L1,L2;
	JTextField T1,T2;
	JButton B1;
	GridBagConstraints gbc;
	JOptionPane ob;
	
	
	STUDENT()
	{
        F = new JFrame("STUDENT WINDOW");
		
		F.setLayout(new FlowLayout());
		
		F.setSize(600, 300);
		F.setVisible(true);
		
		 F.setPreferredSize(new Dimension(550, 300));
	      F.getContentPane().setBackground(Color.GRAY);
	      F.pack();
	      F.setVisible(true);   
		
	      gbc = new GridBagConstraints();  
	  	
	  	
	  	L1 = new JLabel("NAME : ");
	  	L2 = new JLabel("PASSWORD : ");
	  	
	  	L1.setFont((new Font("Tahoma", Font.BOLD, 15)));
	  	L2.setFont((new Font("Tahoma", Font.BOLD, 15)));

	  	
	  	T1 =  new JTextField(30);
	  	T2 =  new JTextField(30);
	  	
	  	
	  	B1 = new JButton(" LOGIN ");
	  	B1.setBackground(Color.WHITE);
	  	//B2.setBackground(Color.green);
	  	
	  	F.setResizable(false);
	  	F.setLocationRelativeTo(null);

	  	
	  	
	  	F.setLayout(new GridBagLayout());
	  	
	    	gbc.gridx = 0;  
	      gbc.gridy = 0;  
	      F.add(L1, gbc);  
	      	    
	      gbc.gridx = 1;  // col  
	      gbc.gridy = 0;  
	      F.add(T1, gbc);
	      
	      gbc.gridx = 0;  
	      gbc.gridy = 1;  
	      F.add(L2, gbc);
	      
	      gbc.gridx = 1;  
	      gbc.gridy = 1;  
	      F.add(T2, gbc);
	      
	      gbc.gridx = 1;  
	      gbc.gridy = 2;  
	      F.add(B1, gbc);
	      
	    
	      

	      
	      B1.addActionListener(this);
	    
	  	

	      
	  	
	  	
	  		
	  	F.setSize(600, 300);
	  	
	  	F.setVisible(true);
	  	
	  	F.setPreferredSize(new Dimension(550, 300));
	      F.getContentPane().setBackground(Color.LIGHT_GRAY);
	      F.pack();
	      F.setVisible(true);   
	  	
	  	}
	  	


	  	public void actionPerformed(ActionEvent e) {
	  		JButton B = (JButton)e.getSource();
	  		
	  		if(B.getActionCommand().equals(" LOGIN "))
	  		{
	  			
	  			String id=T1.getText();
	  			String pwd=T2.getText();
	  			//new Login(id,pwd); 
	  			//System.out.println("hiii");
	  			
	  		
	  			
	  			
	  			java.sql.Statement st=null;   
	  			ResultSet re = null;
	  			
	  			try
	  			{
	  			Class.forName("com.mysql.jdbc.Driver");	 
	  			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/raju","root","");
	  			st = con.createStatement();
	  			re = st.executeQuery("Select * from user ");
	  			while(re.next())
	  			{
	  				
	  				
	  				if(id.equals(re.getString("email"))   && pwd.equals(re.getString("password")))
	  				{
	  					new LibraryOperations();
	  					F.dispose();
	  					break;
	  				}
	  				else
	  				{
	  					ob.showMessageDialog(F, "INVALID PASSWORD");
	  					
	  				} 
	  			}
	  		
	  		
	  		    con.close();

	  			
	  			}
	  			catch(Exception e1)
	  			{
	  				e1.printStackTrace();
	  			}
	  		  }
	  		  else 
	  		  {
	  			  System.out.println("raju");   
	  		  }
	  			 			 						
	  		}

	}


