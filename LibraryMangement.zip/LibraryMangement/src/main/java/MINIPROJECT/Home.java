package MINIPROJECT;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class Home implements ActionListener
{

	JFrame F;
	JButton B1,B2;
	
	
	Home()
	{
		F = new JFrame("Home window");
		
		F.setLayout(new FlowLayout());

		
		
	
		
		
		B1 = new JButton(" ADMIN ");
		B2 = new JButton(" STUDENT ");
		
		B1.setBackground(Color.WHITE);
		B2.setBackground(Color.WHITE);
		

		 B1.addActionListener(this);
		 B2.addActionListener(this);
		 
		 
		 
		
		
		F.add(B1);
		F.add(B2);
		
		//F.setResizable(false);
		//F.setLocationRelativeTo(null);

		
		F.setSize(600, 300);
		F.setVisible(true);
		
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		
		//JLabel background = new JLabel(new ImageIcon("C:\\Users\\Raju\\Downloads"));
		
		
		
		

		
	      //F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      F.setPreferredSize(new Dimension(550, 300));
	      F.getContentPane().setBackground(Color.LIGHT_GRAY);
	      F.pack();
	      F.setVisible(true);   
	      
	      
	        
	       
		
		
	}
	public static void main(String...g)
	{
		new Home();
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(21, 11, 484, 427);
		//frmMarkCalculator.getContentPane().add(panel);
		panel.setLayout(null);
		
	}
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==B1)
		{
			F.dispose();
			new ADMINLOGIN();
		}
		if(e.getSource()==B2)
		{
			
			F.dispose();
			new STUDENT();
		}
		
		
		
	}
	
}
