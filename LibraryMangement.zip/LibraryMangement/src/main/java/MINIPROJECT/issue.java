package MINIPROJECT;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class issue implements ActionListener
{
	JFrame frmMarkCalculator;
	
	JLabel L1,L2;
	JTextField T1,T2;
	JButton btnexit,btnCalculate;
	JPanel P1,P2;
	GridBagConstraints gbc;
    JTextField txtm1,txtm2;
	
	issue()
	{
		frmMarkCalculator = new JFrame();
		frmMarkCalculator.setTitle("ISSUE BOOK");
		frmMarkCalculator.setBounds(100, 100, 557, 488);
		frmMarkCalculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMarkCalculator.getContentPane().setLayout(null);
		
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(21, 11, 484, 427);
		frmMarkCalculator.getContentPane().add(panel);
		panel.setLayout(null);
		
		
		txtm1 = new JTextField(10);
		txtm1.setBounds(285, 70, 128, 20);
		panel.add(txtm1);
		
		
		JLabel firstsub = new JLabel("BOOK id");
		firstsub.setFont(new Font("Tahoma", Font.BOLD, 11));
		firstsub.setBounds(81, 73, 138, 14);
		panel.add(firstsub);
		
		JLabel secondsub = new JLabel("Book Name");
		secondsub.setFont(new Font("Tahoma", Font.BOLD, 11));
		secondsub.setBounds(81, 110, 138, 14);
		panel.add(secondsub);
		
		
		 txtm2 = new JTextField(10);
		
		txtm2.setBounds(285, 107, 128, 20);
		panel.add(txtm2);
		
		 btnCalculate= new JButton(" SUBMIT ");		
		//btnCalculate.setBackground(Color.CYAN);
		btnCalculate.setBounds(176, 369, 114, 23);
		panel.add(btnCalculate);
		
	 btnexit = new JButton(" CLEAR ");
		btnexit.setBounds(348, 369, 89, 23);
		panel.add(btnexit);
		
		btnCalculate.addActionListener(this);
		btnexit.addActionListener(this);
		
		
		frmMarkCalculator.setVisible(true);
		
		
		btnCalculate.setBackground(Color.WHITE);
		btnexit.setBackground(Color.WHITE);

				
		
	}
	
	

	public void actionPerformed(ActionEvent e) 
	{
		
		
			if(e.getSource()==btnCalculate)
			{
				System.out.println("SUBMIT");
				int bid = Integer.parseInt(txtm1.getText());
			String bnamed=  (txtm2.getText());
				
			
			String val=null;
			String sub=null;
				java.sql.PreparedStatement ps=null;

				try
				{
				Class.forName("com.mysql.jdbc.Driver");	 
				java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/raju","root","");
				Statement st = con.createStatement();
				ResultSet re = st.executeQuery("Select * from books where bid="+bid);
				
				while(re.next())
				{
					val =re.getString("issued_status");
					sub=re.getString("bname");
					
					break;
				}
				if(val.equals("yes"))
				{
					JOptionPane.showMessageDialog(frmMarkCalculator, sub+"  IS ALREADY ISSUED");
				}
				else
				{
					ps = con.prepareStatement("UPDATE `books` SET `issued_status` = ? WHERE `books`.`bid` = ?");

					ps.setString(1, "yes");
					ps.setInt(2, bid);
				
					JOptionPane.showMessageDialog(frmMarkCalculator, sub+" BOOK IS  ISSUED SUCCESSFULLY");
					boolean b = ps.execute();
		             
					
				}
				
				
				
				
			
				

			    con.close();
			   System.out.println("executed");

				
				}
				catch(Exception e1)
				{
					e1.printStackTrace();
				}
			  
				
			}
			if(e.getSource()==btnexit)
			{
				txtm1.setText(null);
				txtm2.setText(null);
				
			}
			
	
		
		
		
        
	}
	
	
	
}

