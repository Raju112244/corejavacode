package MINIPROJECT;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;

public class enterBook implements ActionListener
{  
	JFrame F;
	JLabel L1,L2;
	JTextField T1,T2;
	JButton B1,B2;
	GridBagConstraints gbc;
	
    
	enterBook()
	{
	
		F = new JFrame("ENTER BOOK");
		
		gbc = new GridBagConstraints();  
		
	L1 = new JLabel("BOOK NAME : ");
	L2 = new JLabel("BOOK COST : ");
	
	L1.setFont((new Font("Tahoma", Font.BOLD, 15)));
	L2.setFont((new Font("Tahoma", Font.BOLD, 15)));
	
	T1 =  new JTextField(30);
	T2 =  new JTextField(30);
	
	
	B1 = new JButton(" ADD ");
	
	F.setResizable(false);
	F.setLocationRelativeTo(null);

	
	
	F.setLayout(new GridBagLayout());
	
  	gbc.gridx = 0;  
    gbc.gridy = 0;  
    F.add(L1, gbc);  
    	    
    gbc.gridx = 1;  // col  
    gbc.gridy = 0;  
    F.add(T1, gbc);
    
    gbc.gridx = 0;  
    gbc.gridy = 1;  
    F.add(L2, gbc);
    
    gbc.gridx = 1;  
    gbc.gridy = 1;  
    F.add(T2, gbc);
    
    gbc.gridx = 1;  
    gbc.gridy = 2;  
    F.add(B1, gbc);
    
  
    
    B1.setBackground(Color.WHITE);
    
    B1.addActionListener(this);
  
	

    
	
	
		
	F.setSize(600, 300);
	
	F.setVisible(true);
	
	
	F.setPreferredSize(new Dimension(550, 300));
    F.getContentPane().setBackground(Color.LIGHT_GRAY);
    F.pack();
    F.setVisible(true);   
	}


	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==B1)
		{
			
			String name=T1.getText();
			String cost=T2.getText();
			//new Login(id,pwd); 
			//System.out.println("hiii");
			
		
			
			
			
			java.sql.PreparedStatement ps=null;

			try
			{
			Class.forName("com.mysql.jdbc.Driver");	 
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/raju","root","");
			ps = con.prepareStatement("insert into books (bname,bcost,issued_status) values(?,?,?)");

			ps.setString(1, name);
		
			ps.setString(2,cost);
			
			ps.setString(3,"no");
			
			boolean b = ps.execute();
             
			JOptionPane.showMessageDialog(F, "ADDED SUCCESSFULLY");

		    con.close();
		    new LibraryOperations();

			
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
			}
		  }
		  else 
		  {
			  System.out.println("raju");   
		  }
			 			
			
		}
		
	}

