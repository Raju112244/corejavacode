package MINIPROJECT;

import java.awt.FlowLayout;
import java.sql.DriverManager;

import javax.swing.JFrame;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import java.sql.*;

import javax.sql.*;


public class Login 
{
	JFrame F;
	

	Login(String id, String pwd)
	{
		
       F = new JFrame("Home window");
		F.setLayout(new FlowLayout());
		
		
		java.sql.Statement st=null;   
		ResultSet re = null;

		
		try
		{
		Class.forName("com.mysql.jdbc.Driver");	 
		java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/raju","root","");
		st = con.createStatement();
		re = st.executeQuery("Select * from user ");
		while(re.next())
		{
			System.out.println("id"+id);
			System.out.println("pwd"+pwd);
			System.out.println("email"+re.getString("email"));
			System.out.println("password"+re.getString("password"));


			
			if(id.equals(re.getString("email"))   && pwd.equals(re.getString("password")))
			{
				System.out.println("emailll");
			}
			else
			{
				System.out.println("not valid");
			}
		}
	
	
	    con.close();

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


		
		
		
		F.setResizable(false);
		F.setLocationRelativeTo(null);
		F.setSize(600, 300);
		F.setVisible(true);

	}
}
