package MINIPROJECT;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public  class LibraryOperations implements ActionListener
{

	JFrame F;
	JButton B1,B2,B3,B4;
	GridBagConstraints gbc;
	
	LibraryOperations()
	{
		JPanel panel = new JPanel();
	      panel.setBorder(new EmptyBorder(2,3,2,2));
	      panel.setBackground(Color.LIGHT_GRAY);
	      JPanel layout = new JPanel(new GridBagLayout());
	     // layout.setBorder(new EmptyBorder(5, 5, 5, 5));
	     JPanel btnPanel = new JPanel(new GridLayout(10, 1, 10, 5));
	     btnPanel.setBackground(Color.LIGHT_GRAY);
	      B1=  new JButton("ENTRY OF BOOKS");
	      B2 = new JButton("SHOWING BOOK LIST");
	      B3= new JButton("ISSUE BOOK");
	      B4= new JButton("RETURN BOOK");
	      
	      B1.setBackground(Color.WHITE);
	      B2.setBackground(Color.WHITE);
	      B3.setBackground(Color.WHITE);
	      B4.setBackground(Color.WHITE);
	    		  
	      btnPanel.add(B1);
	      btnPanel.add(B2);
	      btnPanel.add(B3);
	      btnPanel.add(B4);
	      
	      B1.addActionListener(this);
			 B2.addActionListener(this);
			 B3.addActionListener(this);
			 B4.addActionListener(this);
	     
	      layout.add(btnPanel);
	      panel.add(layout, BorderLayout.CENTER);
	      JFrame frame = new JFrame("library operations");
	      frame.add(panel);
	      frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	      frame.setLocationByPlatform(true);
	      frame.setSize(1000, 400);
	      //frame.setVisible(true);
	      
	      frame.setPreferredSize(new Dimension(550, 300));
	      frame.getContentPane().setBackground(Color.GRAY);
	      //frame.pack();
	      frame.setVisible(true);   
	       
	  	
	}
	
	public void actionPerformed(ActionEvent e) 
	{
		
		if(e.getSource()==B1)
		{
			new enterBook();
			
		}
		if(e.getSource()==B2)
		{
			new showBook();
		}
		if(e.getSource()==B3)
		{
			new issue();
		}
		if(e.getSource()==B4)
		{
			new returnBook();
		}
		
	}

		
}
