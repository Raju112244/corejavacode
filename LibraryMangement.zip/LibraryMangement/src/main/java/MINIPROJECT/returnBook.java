package MINIPROJECT;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class returnBook implements ActionListener
{
	
	JFrame F;
	JLabel L1,L2;
	JTextField T1,T2;
	JButton B1;
	GridBagConstraints gbc;
	JOptionPane ob;
	
	
	returnBook()
	{
        F = new JFrame("RETURN BOOK");
		
		F.setLayout(new FlowLayout());
		
		F.setSize(600, 300);
		F.setVisible(true);
		
		 F.setPreferredSize(new Dimension(550, 300));
	      F.getContentPane().setBackground(Color.GRAY);
	      F.pack();
	      F.setVisible(true);   
		
	      gbc = new GridBagConstraints();  
	  	
	  	
	  	L1 = new JLabel("BOOK  ID : ");
	  	L2 = new JLabel("BOOK NAME : ");
	  	
	  	L1.setFont((new Font("Tahoma", Font.BOLD, 15)));
	  	L2.setFont((new Font("Tahoma", Font.BOLD, 15)));

	  	
	  	T1 =  new JTextField(30);
	  	T2 =  new JTextField(30);
	  	
	  	
	  	B1 = new JButton(" RETURN ");
	  	B1.setBackground(Color.WHITE);
	  	//B2.setBackground(Color.green);
	  	
	  	F.setResizable(false);
	  	F.setLocationRelativeTo(null);

	  	
	  	
	  	F.setLayout(new GridBagLayout());
	  	
	    	gbc.gridx = 0;  
	      gbc.gridy = 0;  
	      F.add(L1, gbc);  
	      	    
	      gbc.gridx = 1;  // col  
	      gbc.gridy = 0;  
	      F.add(T1, gbc);
	      
	      gbc.gridx = 0;  
	      gbc.gridy = 1;  
	      F.add(L2, gbc);
	      
	      gbc.gridx = 1;  
	      gbc.gridy = 1;  
	      F.add(T2, gbc);
	      
	      gbc.gridx = 1;  
	      gbc.gridy = 2;  
	      F.add(B1, gbc);
	      
	     // B1.setBackground(Color.WHITE);
	      

	      
	      B1.addActionListener(this);
	      
	    
	  	

	      
	  	
	  	
	  		
	  	F.setSize(600, 300);
	  	
	  	F.setVisible(true);
	  	
	  	F.setPreferredSize(new Dimension(550, 300));
	      F.getContentPane().setBackground(Color.LIGHT_GRAY);
	      F.pack();
	      F.setVisible(true);   
	  	
	  	}


	public void actionPerformed(ActionEvent e) 
	{
		// TODO Auto-generated method stub
		if(e.getSource()==B1)
		{
			
			int id=Integer.parseInt(T1.getText());
			String name=T2.getText();

			
			java.sql.PreparedStatement ps=null;

			try
			{
			Class.forName("com.mysql.jdbc.Driver");	 
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/raju","root","");
			ps = con.prepareStatement("UPDATE `books` SET `issued_status` = ? WHERE `books`.`bid` = ?");

			ps.setString(1,"no");
		
			ps.setInt(2,id);
			
		
			
			boolean b = ps.execute();
             
			JOptionPane.showMessageDialog(F, "RETURN SUCCESSFULLY");

		    con.close();
		    new LibraryOperations();

			
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
			}
		  }
		  else 
		  {
			  System.out.println("raju");   
		  }
			 			
	}
	  	
	
}
